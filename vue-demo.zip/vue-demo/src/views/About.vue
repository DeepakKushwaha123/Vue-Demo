<template>
  <div class="about">
    <h1 class="text-white">This is an about page</h1>
  </div>
</template>
